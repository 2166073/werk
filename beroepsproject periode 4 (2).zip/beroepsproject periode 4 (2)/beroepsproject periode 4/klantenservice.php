<!DOCTYPE html>
<html lang="en">
<head>
    <title>Klantservice - Flower</title>
    <link rel="stylesheet" type="text/css" href="klantservice.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="flower.png" class="logo" alt="Flower Logo">
            <ul>
                <li><a href="homepage.php">Home</a></li>
                <li><a href="overons.php">Over Ons</a></li>
                <li><a href="klantenservice.php">Klantservice</a></li>
                <li><a href="service.php">Onze Service</a></li>
                <li><a href="inloggen.php">Inloggen</a></li>
            </ul>
        </div>
    </div>

    <div class="service-container">
        <h1>Klantenservice - Flower</h1>
        <p>Bij Flower is klantenservice onze hoogste prioriteit. We begrijpen dat tevreden klanten de hoeksteen zijn 
            van ons succes, en we zijn er trots op om u de best mogelijke ondersteuning te bieden.</p>
        <div class="service-item">
            <h2>Deskundige Ondersteuning</h2>
            <p>Ons team van deskundigen staat klaar om uw vragen te beantwoorden en u te begeleiden
                 bij het maken van de juiste keuzes. Of u nu advies wilt over welk bloemstuk het beste bij uw gelegenheid past, 
                 of gewoon meer informatie wilt over ons productaanbod, wij zijn hier om te helpen.</p>
        </div>

        <div class="service-item">
            <h2>Snelle Respons</h2>
            <p>Wij begrijpen het belang van een snelle respons. 
                U kunt rekenen op een tijdige reactie op uw vragen en verzoeken. 
                Ons doel is om u snel de informatie te bieden die u nodig heeft, 
                of het nu gaat om productinformatie, orderstatus of algemene vragen.</p>
        </div>

        <div class="service-item">
            <h2>Transparantie en Betrouwbaarheid</h2>
            <p>Bij Flower geloven we in transparantie en betrouwbaarheid. 
                Onze prijzen en voorwaarden zijn duidelijk en eerlijk. 
                We zorgen ervoor dat u altijd op de hoogte bent van de status van uw bestelling en
                 bieden u de flexibiliteit om wijzigingen aan te brengen wanneer dat nodig is.</p>
        </div>

        <div class="service-item">
            <h2>Eenvoudige Retourprocedure</h2>
            <p>Mocht u om welke reden dan ook niet tevreden zijn
                 met uw aankoop, dan bieden we een eenvoudige retourprocedure.
                  Ons doel is om ervoor te zorgen dat u tevreden bent met uw aankoop bij Flower,
                   en we zullen er alles aan doen om eventuele problemen op te lossen.</p>
        </div>

        <div class="service-item">
            <h2>Toekomstige Ondersteuning</h2>
            <p>Onze klantenservice stopt niet bij uw aankoop.
                 We blijven beschikbaar voor eventuele vragen of problemen die zich in de toekomst kunnen voordoen. 
                 Of het nu gaat om nieuwe bloemarrangementen, advies over plantverzorging of aanvullende diensten, we blijven uw partner 
                 in uw bloemenreis.</p>
        </div>
        
        <a href="contact.php" class="contact-button">Neem contact met ons op</a>
    </div>

    <section class="footer">
        <p>Osdorp Aker Amsterdam 1075GF | Phone: +31 6960840 | Email: FlowerxInfo@gmail.com </p>
        <p>Copyright @ 2023 Flower</p>
    </section>
</body>
</html>