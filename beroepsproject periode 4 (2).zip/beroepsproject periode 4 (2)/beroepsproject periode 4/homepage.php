
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FLOWER</title>

    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>
<body>
</header>

<div class="banner">
        <div class="navbar">
            <img src="flower.png" class="logo">

        <ul>
            <li><a href="homepage.php">HOME</a></li>
            <li><a href="overons.php">OVER ONS</a></li>
            <li><a href="klantenservice.php">KLANTENSERVICE</a></li>
            <li><a href="service.php">ONZE SERVICE</a></li>
        </ul>
    </div>
    
    


 <header>
    <div class="header">
        <h2>Welkom bij flower</h2>
      <div class="line"></div>
      <h1>bekijk onze bloemen</h1>
  <a href="/beroepsprojectleerjaar2/homepage.php/samsung.html" class="ctn" >Zie meer</a>
      
    </div>
 </header>

 <section class="service">
  <div class="title">
    <h1>OverOns</h1>
    <div class="line"></div>
  </div>
  <div class="row">
    <div class="col">
    
      <h4>Welkom</h4>
      <p>Welkom bij Flower, jouw bestemming voor prachtige bloemen en unieke arrangementen.
         Bij ons vind je de mooiste selectie bloemen, zorgvuldig samengesteld om elke gelegenheid extra speciaal te maken.
          Of je nu op zoek bent naar een romantisch boeket, een vrolijke verjaardagsverrassing, of een stijlvolle toevoeging aan je interieur, 
          bij Flower ben je aan het juiste adres. Laat je inspireren door onze creaties en ontdek de magie van bloemen.
      </p>

      <a href="overons.php" class="ctn">Lees meer</a>
      </div>
  </div>
 </section>

 <section class="klanten">
  <div class="explore">
  <h1>klantenservice</h1>
  <div class="line"></div>
  <p>Heeft u vragen over onze bloemen<br>
  dan helpen 1 van onze expers u graag<br>
  Vul dan het contact formulier in<br>
  Of bel naar +31 6303479</p>
  <a href="contact.php" class="ctn">Neem contact</a>
  </div>
 </section>

 <section class="tours">
 <div class="row">
  <div class="col content-col">
    <h1>Onze Service</h1>
    <div class="line"></div>
    <p>Bij Flower bieden we uitzonderlijke service en kwaliteit. 
      Onze ervaren bloemisten creëren prachtige arrangementen op maat, precies zoals jij het wilt. 
      We garanderen verse bloemen, snelle levering en een persoonlijke touch voor elke bestelling. 
      Of het nu gaat om een speciale gelegenheid of een dagelijkse verrassing, wij zorgen voor een vlekkeloze en 
      onvergetelijke ervaring. Kies voor Flower en geniet van service die bloeit.
    </p>
    <a href="onzeservice.php" class="ctn">lees meer</a>
  </div>
 <div class="col image-col">
  <div class="image-gallery">
    <img src="flower6.png" alt="">
    <img src="flower7.png" alt="">
    <img src="flower8.png" alt="">
    <img src="flower9.png" alt="">
  </div>
 </div>
</div>
 </section>

 <section class="footer">
    <p>Osdorp Aker Amsterdam 1075GF | Phone: +31 6960840 | Email: FlowerxInfo@gmail.com </p>
    <p>Copyright @ 2023 Outdoor nature</p>
 </section>



</body>
</html>