<?php
include 'db.php';

class Afspraak { 
    private $db;

    public function __construct() {
        $this->db = new DB('agenda'); 
    }

    public function addAfspraak($datum, $tijd, $omschrijving) {
        $sql = "INSERT INTO Afspraken (datum, tijd, omschrijving) VALUES (?, ?, ?)";
        return $this->db->executeQuery($sql, array($datum, $tijd, $omschrijving));

    }

    public function getAllAfspraak() {
        $sql = "SELECT * FROM Afspraken"; 
        $stmt = $this->db->executeQuery($sql); 
        return $this->db->fetchAll($stmt);
    }

    public function updateAfspraak($datum, $tijd, $omschrijving, $afspraakid) {
        $sql = "UPDATE Afspraken SET datum=?, tijd=?, omschrijving=? WHERE afspraakid=?";
        return $this->db->executeQuery($sql, array($datum, $tijd, $omschrijving, $afspraakid));
    }

    public function deleteAfspraak($afspraakid) {
        $sql = "DELETE FROM Afspraken WHERE afspraakid = ?";
        return $this->db->executeQuery($sql, array($afspraakid));
    }
}
?>