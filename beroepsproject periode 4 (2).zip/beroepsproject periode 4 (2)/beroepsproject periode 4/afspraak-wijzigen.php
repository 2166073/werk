<?php
include 'agenda.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $datum = $_POST['datum'];
    $tijd = $_POST['tijd'];
    $omschrijving = $_POST['omschrijving'];
    $afspraakid = $_POST['afspraakid'];

    $afspraak = new Afspraak();
    $result = $afspraak->updateAfspraak($datum, $tijd, $omschrijving, $afspraakid);

    if ($result) {
        echo "Afspraak is succesvol bijgewerkt!";
    } else {
        echo "Er is een fout opgetreden bij het bijwerken van je afspraak.";
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <title>Bewerk je afspraak</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="formulier-container">
        <h1>Bewerk je afspraak</h1>
        <form method="POST">
            <input type="hidden" name="afspraakid" value="<?php echo $_GET['id']; ?>"> 
            <label for="datum">Datum:</label>
            <input type="date" id="datum" name="datum" required><br><br>
            <label for="tijd">Tijd:</label>
            <input type="time" id="tijd" name="tijd" required><br><br>
            <label for="omschrijving">Omschrijving:</label>
            <input type="text" id="omschrijving" name="omschrijving" required><br><br>
            <input type="submit" value="Bewerken">
            <a href="agenda-overzicht.php">Terug</a>
        </form>
    </div>
</body>
</html>
