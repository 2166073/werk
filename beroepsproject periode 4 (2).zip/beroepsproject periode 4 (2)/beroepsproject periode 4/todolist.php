<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>To-Do List</title>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style 1.css">
</head>
<body>
</header>

<div class="banner">
        <div class="navbar">
            <img src="flower.png" class="logo">

        <ul>
            <li><a href="homepage.php">HOME</a></li>
            <li><a href="overons.php">OVER ONS</a></li>
            <li><a href="klantenservice.php">KLANTENSERVICE</a></li>
            <li><a href="service.php">ONZE SERVICE</a></li>
        </ul>
    </div>
    
    


 <header></header>


<div class="container">
<div class="todo-container">
<h1>To-Do List</h1>
<?php
                session_start();
                if (!isset($_SESSION['tasks'])) {
                    $_SESSION['tasks'] = array();
                }
 
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    if (isset($_POST['new_task']) && !empty(trim($_POST['new_task']))) {
                        $new_task = htmlspecialchars($_POST['new_task']);
                        array_push($_SESSION['tasks'], $new_task);
                    }
 
                    if (isset($_POST['delete_task'])) {
                        $task_index = $_POST['delete_task'];
                        unset($_SESSION['tasks'][$task_index]);
                        $_SESSION['tasks'] = array_values($_SESSION['tasks']);
                    }
                }
            ?>
 
            <form method="post" action="" class="form-inline">
<div class="form-group">
<input name="new_task" type="text" class="form-control" placeholder="New task">
</div>
<button type="submit" class="btn btn-primary">Add Task</button>
</form>
 
            <ul class="task-list mt-3">
<?php foreach ($_SESSION['tasks'] as $index => $task) : ?>
<li>
<?php echo $task; ?>
<form method="post" action="">
<input type="hidden" name="delete_task" value="<?php echo $index; ?>">
<button type="submit">&times;</button>
</form>
</li>
<?php endforeach; ?>
</ul>
</div>
</div>
 
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

