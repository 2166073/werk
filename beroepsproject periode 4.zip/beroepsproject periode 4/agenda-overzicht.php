<!DOCTYPE html>
<html lang="nl">
<head>
    <title>Agenda</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="banner">
        <div class="navbar">
            <img src="flower.png" class="logo">

        <ul>
            <li><a href="homepage.php">HOME</a></li>
            <li><a href="overons.php">OVER ONS</a></li>
            <li><a href="klantenservice.php">KLANTENSERVICE</a></li>
            <li><a href="service.php">ONZE SERVICE</a></li>
        </ul>
    </div>

<div class="agenda">
    <h1>Agenda</h1>
    <?php
    include 'agenda.php'; 

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
        $afspraak = new Afspraak(); 
        $deletedRows = $afspraak->deleteAfspraak($_POST['delete_id']); 
        if ($deletedRows === false) {
            echo "<p>Er is een fout opgetreden bij het verwijderen van je afspraak.</p>";
        } else {
            echo "<p>Afspraak succesvol verwijderd.</p>";
        }
    }

    $afspraak = new Afspraak(); 
    $data = $afspraak->getAllAfspraak();
    
    $maanden = array(
        1 => 'Januari', 2 => 'Februari', 3 => 'Maart', 4 => 'April', 
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Augustus', 
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'December'
    );

    $huidigeMaand = null;

    foreach ($data as $rij) {
        $afspraakDatum = strtotime($rij['datum']);
        $maand = date('n', $afspraakDatum);
        if ($maand != $huidigeMaand) {
            if ($huidigeMaand !== null) {
                echo "</ul>";
            }
            $huidigeMaand = $maand;
            echo "<div class='maand'><h2>".$maanden[$huidigeMaand]."</h2></div>";
            echo "<ul class='afspraken'>";
        }
        
        echo "<li class='afspraak'>";
        echo "<h3>".date('d-m-Y', $afspraakDatum)." om ".$rij['tijd']."</h3>"; 
        echo "<p>".$rij['omschrijving']."</p>"; 
        echo "<div class='acties'>
                <a href='afspraak-wijzigen.php?id=".$rij['afspraakid']."'>Wijzigen</a> 
                <form method='POST' style='display:inline;'>
                  <input type='hidden' name='delete_id' value='".$rij['afspraakid']."'>
                  <button type='submit'>Verwijderen</button>
                </form>
              </div>"; 
        echo "</li>";
    }
    if ($huidigeMaand !== null) {
        echo "</ul>";
    }
    ?>
    <a href="afspraak-toevoegen.php" class="nieuwe-afspraak">Nieuwe afspraak toevoegen</a>
</div>
</body>
</html>
