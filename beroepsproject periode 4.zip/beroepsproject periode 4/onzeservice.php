
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FLOWER</title>

    <link rel="stylesheet" href="service.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>
<body>
</header>

        <div class="navbar">
            <img src="flower.png" class="logo">

        <ul>
            <li><a href="homepage.php">HOME</a></li>
            <li><a href="overons.php">OVER ONS</a></li>
            <li><a href="klantenservice.php">KLANTENSERVICE</a></li>
            <li><a href="service.php">ONZE SERVICE</a></li>
        </ul>
    </div>
    
    

    <header>
    <div class="header">
        <h2>Welkom bij FLOWER SERVICE</h2>
      <div class="line"></div>
    </div>
 </header>


 <section class="service">
  <div class="title">
    <h1>Onze service bij flower</h1>
    <div class="line"></div>
  </div>
  <div class="row">
    <div class="col">
    
      <h4>Welkom</h4>
      <p>Bij Flower leveren we prachtige bloemarrangementen voor elke gelegenheid. Geniet van onze bloemenabonnementen en ontvang regelmatig verse bloemen aan huis.
         Voor bruiloften en evenementen creëren we op maat gemaakte bloemstukken die perfect aansluiten bij uw wensen. Onze bedrijfsbloemistendiensten zorgen voor een
          stijlvolle werkplek met elegante bloemstukken. Met onze betrouwbare bezorgservice kunt u geliefden verrassen met verse bloemen aan de deur. 
          We bieden persoonlijke aandacht en deskundig advies om aan al uw bloemwensen te voldoen. Bij Flower staat klanttevredenheid centraal, 
          en dat ziet u in elke bloem die we leveren. Ontdek vandaag de magie van bloemen met Flower!
      </p>
      </div>
  </div>
 </section>

 <section class="klanten">
  <div class="explore">
  <h1>Maak een afspraak</h1>
  <div class="line"></div>
  <p>Heeft u vragen over onze bloemen<br>
  dan helpen 1 van onze expers u graag<br>
  kies een datum uit om een afspraak in te plannen,</p>
  <a href="agenda-overzicht.php" class="ctn">Maak een afspraak</a>
  </div>

  <!-- hier komt de code voor agenda -->
 </section>

 <section class="tours">
  <div class="col content-col">
    <h1>Maak een to do list</h1>
    <div class="line"></div>
    <p>Weet je het soms ook effe niet meer wat de stappenzij, om bloemen te laten bloeien. Vul dan effe voor je zelf een 
        to do list. Zodat je het nooit gaat vergeten.
    </p>
    <a href="todolist.php" class="ctn">Maak to do list</a>

    <!-- hier komt de code van to do list -->
</div>
 </section>

 <section class="tours">
  <div class="col content-col">
    <h1>Reken uit</h1>
    <div class="line"></div>
    <p>Doe eens leuk en reken uit met een rekenmachine hoeveel het gaat kosten.
    <a href="rekenmachine.html" class="ctn">rekenmachine</a>

    <!-- hier komt de code van to do list -->
</div>
 </section>

 <section class="footer">
    <p>Osdorp Aker Amsterdam 1075GF | Phone: +31 6960840 | Email: FlowerxInfo@gmail.com </p>
    <p>Copyright @ 2023 Outdoor nature</p>
 </section>



</body>
</html>