<?php
include 'agenda.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $datum = $_POST['datum'];
    $tijd = $_POST['tijd'];
    $omschrijving = $_POST['omschrijving'];
    
    $afspraak = new Afspraak(); 
    $result = $afspraak->addAfspraak($datum, $tijd, $omschrijving); 

    if ($result) {
        echo "<p>Afspraak succesvol toegevoegd!</p>";
    } else {
        echo "<p>Er is een fout opgetreden bij het toevoegen van je afspraak.</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <title>Afspraak Toevoegen</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="formulier-container">
        <h2>Afspraak Toevoegen</h2>
        <form action="" method="post">
            <label for="datum">Datum:</label>
            <input type="date" id="datum" name="datum" required><br><br>
            <label for="tijd">Tijd:</label>
            <input type="time" id="tijd" name="tijd" required><br><br>
            <label for="omschrijving">Omschrijving:</label>
            <input type="text" id="omschrijving" name="omschrijving" required><br><br>
            <input type="submit" value="Toevoegen">
            <a href="agenda-overzicht.php">Terug</a>
        </form>
    </div>
</body>
</html>
