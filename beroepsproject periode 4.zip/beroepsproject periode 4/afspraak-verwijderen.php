<?php
include 'agenda.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['telefoonID'])) {
    $telefoonID = $_POST['telefoonID'];

    $telefoon = new Afspraak();

    $result = $telefoon->deleteAfspraak($afspraakid);

    if ($result) {
        echo "Afspraak succesvol verwijderd!";
    } else {
        echo "Er is een fout opgetreden bij het verwijderen van je afspraak.";
    }
}
?>
