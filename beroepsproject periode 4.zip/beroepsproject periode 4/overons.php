<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="ons.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flower - Over Ons</title>
</head>
<body>
    
<div class="banner">
    <div class="navbar">
        <img src="flower.png" class="logo" alt="Flower Logo">
        <ul>
            <li><a href="homepage.php">Home</a></li>
            <li><a href="overons.php">Over Ons</a></li>
            <li><a href="klantenservice.php">Klantservice</a></li>
            <li><a href="service.php">Onze Service</a></li>
            <li><a href="#">Inloggen</a></li>
        </ul>
    </div>
</div>

<div class="about-us">
    <div class="mission">
        <h2>Onze Missie</h2>
        <p>Bij Flower begrijpen we de belangrijke rol die bloemen spelen in ons dagelijks leven. 
            Onze missie is om klanten de mooiste, meest verse bloemen en arrangementen te bieden, 
            zodat ze elke gelegenheid extra speciaal kunnen maken.</p>
    </div>

    <div class="product-range">
        <h2>Een Breed Assortiment</h2>
        <p>Onze winkel beschikt over een uitgebreid assortiment bloemen en planten,
            van klassieke rozen tot exotische orchideeën. Of je nu op zoek bent naar een romantisch boeket, 
            een vrolijke verjaardagsverrassing, of een stijlvolle toevoeging aan je interieur, je zult zeker iets 
            vinden dat aan je wensen voldoet.</p>
    </div>

    <div class="customer-service">
        <h2>Uitzonderlijke Klantenservice</h2>
        <p>Bij Flower gaat onze toewijding verder dan alleen het aanbieden van bloemen.
             Wij streven ernaar om je winkelervaring moeiteloos en plezierig te maken. 
             Ons vriendelijke en deskundige klantenserviceteam staat altijd klaar om je vragen te beantwoorden en 
             je te helpen bij het maken van de juiste keuze.</p>
    </div>

    <div class="security-quality">
        <h2>Veiligheid en Kwaliteit</h2>
        <p>We hechten de hoogste waarde aan de veiligheid van je persoonlijke gegevens
             en je tevredenheid met onze producten. Bij Flower worden al onze bloemen met zorg 
             geselecteerd en gecontroleerd om ervoor te zorgen dat je hoogwaardige producten ontvangt 
             die aan je verwachtingen voldoen.</p>
    </div>

    <div class="contact-us">
        <h2>Contacteer Ons</h2>
        <p>Heb je vragen, opmerkingen of suggesties? Wij staan voor je klaar. 
            Neem gerust contact met ons op via onze klantenservice. We danken je voor je vertrouwen in Flower.</p>
    </div>
</div>

<section class="footer">
    <p>Osdorp Aker Amsterdam 1075GF | Phone: +31 6960840 | Email: FlowerxInfo@gmail.com </p>
    <p>Copyright @ 2023 Outdoor nature</p>
 </section>

</body>
</html>
