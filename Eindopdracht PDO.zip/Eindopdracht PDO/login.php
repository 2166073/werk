<?php
include 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $role = $_POST['role'];

    try {
        $sql = "SELECT * FROM users WHERE username = :username AND password = :password AND role = :role";
        $stmt = $myDb->dbh->prepare($sql); // Gebruik de dbh van het $myDb-object
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':role', $role);
        $stmt->execute();
        
        if ($stmt->rowCount() == 1) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            if ($user['role'] == 'DOCENT') {
                header('Location: dashboard.php');
            } elseif ($user['role'] == 'ROOSTERMAKER') {
                header('Location: indexx.php');
            } elseif ($user['role'] == 'STUDENT') {
                header('Location: student_rooster.php'); // Verwijs studenten naar de nieuwe pagina
            } else {
                header('Location: gesprekken.php');
            }
            exit;
        } else {
            echo "Invalid username, password, or role";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body style="background-image: url('loginfoto.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat; height: 100vh; margin: 0;">
    <header>
        <img src="logo.png" alt="IT Lyceum Logo">
        <h1>IT Lyceum - Mentor Gesprek</h1>
        <div class="dropdown">
            <?php if (isset($_SESSION['username'])): ?>
                <button><?php echo $_SESSION['username']; ?> (<?php echo $_SESSION['role']; ?>)</button>
                <div class="dropdown-content">
                    <a href="logout.php">Logout</a>
                </div>
            <?php else: ?>
                <button>Account</button>
                <div class="dropdown-content">
                    <a href="login.php">Login</a>
                    <a href="register.php">Register</a>
                </div>
            <?php endif; ?>
        </div>
    </header>
    <div class="container">
        <h1>Login</h1>
        <form method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <label for="role">Role:</label>
            <select id="role" name="role" required>
                <option value="student">Student</option>
                <option value="docent">Docent</option>
                <option value="mentor">Mentor</option>
                <option value="roostermaker">Roostermaker</option>
                <option value="manager">Manager</option>
            </select>
            <button type="submit">Login</button>
        </form>
        <p>Heb je nog geen account? <a href="register.php">Registreer hier!</a></p>
    </div>
</body>
</html>
