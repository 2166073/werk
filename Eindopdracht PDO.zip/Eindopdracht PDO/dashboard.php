<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Docent Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('docent.jpg'); /* Achtergrondafbeelding toevoegen */
            background-size: cover; /* Afbeelding volledig bedekken */
            background-position: center; /* Afbeelding gecentreerd positioneren */
        }
        .container {
            background-color: rgba(255, 255, 255, 0.8); /* Achtergrond van container licht opmaken */
            padding: 40px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            text-align: center;
            width: 80%;
            max-width: 600px;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        p {
            color: #666;
            margin-bottom: 30px;
        }
        a {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            background-color: #5cb85c;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        a:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>
    <div class="container">
        <p>Dit is de docent dashboard.</p>
        <a href="dashboard.php">Dashboard</a>
        <a href="overzicht_studenten.php">Overzicht Studenten</a>
        <a href="docentgegevens.php">Docent Gegevens</a>
        <a href="vakkenbeheer.php">Vakken Toevoegen</a>
        <a href="vakken_overzicht.php">Vakken Overzicht</a>
        <a href="logout.php">Uitloggen</a>
    </div>
</body>
</html>
