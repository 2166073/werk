<?php
include 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $role = 'STUDENT';

    try {
        $sql = "SELECT * FROM users WHERE username = :username";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo "Username al in gebruik!";
        } else {
            $sql = "INSERT INTO users (username, password, role) VALUES (:username, :password, :role)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':password', $password);
            $stmt->bindParam(':role', $role);
            $stmt->execute();
            echo "Registratie Succesvol! Je kan nu inloggen.<a href='login.php'>login</a>";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <header>
        <img src="logo.png" alt="IT Lyceum Logo">
        <h1>IT Lyceum - Mentor Gesprek</h1>
        <div class="dropdown">
            <?php if (isset($_SESSION['username'])): ?>
                <button><?php echo $_SESSION['username']; ?> (<?php echo $_SESSION['role']; ?>)</button>
                <div class="dropdown-content">
                    <a href="logout.php">Logout</a>
                </div>
            <?php else: ?>
                <button>Account</button>
                <div class="dropdown-content">
                    <a href="login.php">Login</a>
                    <a href="register.php">Register</a>
                </div>
            <?php endif; ?>
        </div>
    </header>
    <div class="container">
        <h1>Register</h1>
        <form method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <button type="submit">Register</button>
            <p>Heb je al een account? <a href="Login.php">Login hier in!</a></p>
        </form>
    </div>
</body>
</html>
