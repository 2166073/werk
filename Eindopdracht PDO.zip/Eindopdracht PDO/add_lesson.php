<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'ROOSTERMAKER') {
    header('Location: login.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $klas = $_POST['klas'];
    $dag = $_POST['dag'];
    $tijdstip = $_POST['tijdstip'];
    $vak = $_POST['vak'];
    $teacher = $_POST['teacher'];

    $currentDate = new DateTime();
    $targetDate = new DateTime($dag);
    $weekOffset = floor(($targetDate->getTimestamp() - $currentDate->modify('monday this week')->getTimestamp()) / (7 * 24 * 60 * 60));

    $servername = "localhost:3307";
    $usernameDB = "root";
    $passwordDB = "";
    $dbname = "databasepdo";

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $usernameDB, $passwordDB);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "INSERT INTO rooster (klas, dag, tijdstip, vak, teacher) VALUES (:klas, :dag, :tijdstip, :vak, :teacher)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':klas', $klas);
        $stmt->bindParam(':dag', $dag);
        $stmt->bindParam(':tijdstip', $tijdstip);
        $stmt->bindParam(':vak', $vak);
        $stmt->bindParam(':teacher', $teacher);

        if ($stmt->execute()) {
            header("Location: indexx.php?klas=$klas&week=$weekOffset");
            exit();
        } else {
            echo "Fout bij het toevoegen van de les.";
        }
    } catch(PDOException $e) {
        echo "Verbinding mislukt: " . $e->getMessage();
    }

    $conn = null;
}
?>
