<?php
include 'Docent.php';
 
$docent = new Docent($myDb);
if (isset($_GET["ID"])) {
    $ID = $_GET["ID"];
    $Docent = $docent->getdocentById($ID); 
}
 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $naam = $_POST["naam"];
        $klas = $_POST["klas"];
        $geboortedatum = $_POST["geboortedatum"];
        $docentennummer = $_POST["docentennummer"];
       
        $docent->updatedocent( $naam, $klas, $geboortedatum, $docentennummer, $ID); 
        header("Location: view-docent.php");
        exit;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
 

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Bewerk Telefoon</title>
</head>
<body>
    <div class="container">
        <h2>Bewerk Docent</h2>
        <form method="POST">
            <input type="hidden" name="ID" value="<?php echo $ID; ?>">
            <div class="mb-3">
                <label class="form-label">naam:</label>
                <input type="text" class="form-control" name="naam" value="<?php echo $Docent['naam']; ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">klas:</label>
                <input type="text" class="form-control" name="klas" value="<?php echo $Docent['klas']; ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">geboortedatum:</label>
                <input type="date-of-birth" class="form-control" name="geboortedatum" value="<?php echo $Docent['geboortedatum']; ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">docentennummer:</label>
                <input type="text" class="form-control" name="docentennummer" value="<?php echo $Docent['docentennummer']; ?>" required>
            </div>
        
            
            <button type="submit" class="btn btn-primary">Opslaan</button>
        </form>
    </div>
</body>
</html>
