<?php
session_start();

// Initialiseer sessievariabelen als ze niet bestaan
if (!isset($_SESSION['docenten'])) {
    $_SESSION['docenten'] = [];
}

// Variabelen voor het opslaan van huidige gegevens
$current_naam = "";
$current_vakgebied = "";
$current_email = "";
$current_telefoon = "";
$current_geboortedatum = "";
$edit_index = -1;

// Haal huidige gegevens op als de index is gespecificeerd
if (isset($_GET['index']) && is_numeric($_GET['index'])) {
    $edit_index = $_GET['index'];
    if (isset($_SESSION['docenten'][$edit_index])) {
        $docent = $_SESSION['docenten'][$edit_index];
        $current_naam = $docent['naam'];
        $current_vakgebied = $docent['vakgebied'];
        $current_email = $docent['email'];
        $current_telefoon = $docent['telefoon'];
        $current_geboortedatum = $docent['geboortedatum'];
    } else {
        echo "<div class='error'>Geen docent gevonden met index: $edit_index</div>";
    }
}

// Verwerk het formulier voor opslaan of bijwerken van gegevens
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $naam = htmlspecialchars($_POST["naam"]);
    $vakgebied = htmlspecialchars($_POST["vakgebied"]);
    $email = htmlspecialchars($_POST["email"]);
    $telefoon = htmlspecialchars($_POST["telefoon"]);
    $geboortedatum = htmlspecialchars($_POST["geboortedatum"]);

    $docent = [
        'naam' => $naam,
        'vakgebied' => $vakgebied,
        'email' => $email,
        'telefoon' => $telefoon,
        'geboortedatum' => $geboortedatum
    ];

    if (isset($_POST['submit']) && $_POST['submit'] == 'Opslaan') {
        // Nieuwe gegevens opslaan
        $_SESSION['docenten'][] = $docent;
        echo "<div class='success'>Nieuwe gegevens succesvol opgeslagen.</div>";
    } elseif (isset($_POST['submit']) && $_POST['submit'] == 'Wijzigen' && $edit_index != -1) {
        // Bestaande gegevens bijwerken
        $_SESSION['docenten'][$edit_index] = $docent;
        echo "<div class='success'>Gegevens succesvol bijgewerkt.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Docent Gegevens</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .navbar {
            width: 100%;
            background-color: #5cb85c;
            padding: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 18px;
            transition: color 0.3s;
        }
        .navbar a:hover {
            color: #e6e6e6;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
            margin-top: 20px;
        }
        h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="email"],
        input[type="date"],
        input[type="tel"] {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box;
        }
        input[type="submit"] {
            padding: 10px;
            background-color: #5cb85c;
            border: none;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        .success {
            color: green;
            margin-top: 20px;
        }
        .error {
            color: red;
            margin-top: 20px;
        }
        .output {
            margin-top: 20px;
            padding: 10px;
            background-color: #e9ecef;
            border-radius: 4px;
        }
        .output ul {
            list-style: none;
            padding: 0;
        }
        .output ul li {
            background-color: #f9f9f9;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        .output ul li:last-child {
            border-bottom: none;
        }
        .output ul li a {
            color: #5cb85c;
            text-decoration: none;
            margin-left: 10px;
        }
        .output ul li a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="navbar">
    <a href="dashboard.php">Dashboard</a>
        <a href="overzicht_studenten.php">Overzicht Studenten</a>
        <a href="docentgegevens.php">Docent Gegevens</a>
        <a href="vakkenbeheer.php">Vakken Toevoegen</a>
        <a href="vakken_overzicht.php">Vakken Overzicht</a>

        <a href="logout.php">Uitloggen</a>
    </div>
    <div class="container">
        <h2><?php echo $edit_index != -1 ? 'Wijzig Docentgegevens' : 'Voer de gegevens van de docent in'; ?></h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . ($edit_index != -1 ? '?index=' . $edit_index : ''); ?>">
            <label for="naam">Naam:</label>
            <input type="text" id="naam" name="naam" value="<?php echo $current_naam; ?>" required>

            <label for="vakgebied">Vakgebied:</label>
            <input type="text" id="vakgebied" name="vakgebied" value="<?php echo $current_vakgebied; ?>" required>

            <label for="email">E-mailadres:</label>
            <input type="email" id="email" name="email" value="<?php echo $current_email; ?>" required>

            <label for="telefoon">Telefoonnummer:</label>
            <input type="tel" id="telefoon" name="telefoon" value="<?php echo $current_telefoon; ?>" required>

            <label for="geboortedatum">Geboortedatum:</label>
            <input type="date" id="geboortedatum" name="geboortedatum" value="<?php echo $current_geboortedatum; ?>" required>

            <?php if ($edit_index != -1): ?>
                <input type="submit" name="submit" value="Wijzigen">
            <?php else: ?>
                <input type="submit" name="submit" value="Opslaan">
            <?php endif; ?>
        </form>

        <h2>Docenten Overzicht</h2>
        <div class="output">
            <?php if (!empty($_SESSION['docenten'])): ?>
                <ul>
                    <?php foreach ($_SESSION['docenten'] as $index => $docent): ?>
                        <li>
                            <?php echo "Naam: " . $docent['naam'] . ", Vakgebied: " . $docent['vakgebied'] . ", E-mail: " . $docent['email'] . ", Telefoon: " . $docent['telefoon'] . ", Geboortedatum: " . $docent['geboortedatum']; ?>
                            <a href="?index=<?php echo $index; ?>">Wijzigen</a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>Geen docenten gevonden.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
