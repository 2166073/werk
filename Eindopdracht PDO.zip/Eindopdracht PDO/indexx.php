<?php
include 'config.php';
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$isRoostermaker = $_SESSION['role'] === 'ROOSTERMAKER';

function getWeekDates($weekOffset = 0) {
    $dates = [];
    $startOfWeek = new DateTime();
    $startOfWeek->modify(($weekOffset * 7) . ' days');
    $startOfWeek->modify('monday this week');

    for ($i = 0; $i < 5; $i++) {
        $dates[] = clone $startOfWeek;
        $startOfWeek->modify('+1 day');
    }

    return $dates;
}

$weekOffset = isset($_GET['week']) ? intval($_GET['week']) : 0;
$weekDates = getWeekDates($weekOffset);
$dagen = ['maandag', 'dinsdag', 'woensdag', 'donderdag', 'vrijdag'];
$dagenEngels = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Roostersysteem</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1>Roostersysteem</h1>
    <div class="container">
        <p>Welkom, <?php echo $_SESSION['username']; ?> | <a href="logout.php">Uitloggen</a></p>
        <form method="GET" action="">
            <label for="klas">Kies een klas:</label>
            <select id="klas" name="klas">
                <option value="OTITOSD2C">OTITOSD2C</option>
                <option value="OTITOSD2E">OTITOSD2E</option>
                <option value="OTITOSD2B">OTITOSD2B</option>
            </select>
            <label for="week">Kies een week:</label>
            <select id="week" name="week">
                <option value="0">Deze week</option>
                <option value="1">Volgende week</option>
                <option value="2">Over 2 weken</option>
                <option value="3">Over 3 weken</option>
            </select>
            <button type="submit">Toon Rooster</button>
        </form>

        <?php
        if (isset($_GET['klas'])) {
            $klas = $_GET['klas'];

            try {
                // Gebruik de bestaande database verbinding
                $conn = $myDb->dbh;

                $tijden = ['08:30:00', '09:30:00', '10:30:00', '11:30:00', '12:30:00', '13:30:00', '14:30:00', '15:30:00', '16:30:00', '17:30:00'];

                $startOfWeek = $weekDates[0]->format('Y-m-d');
                $endOfWeek = $weekDates[4]->format('Y-m-d');
                
                $sql = "SELECT id, dag, tijdstip, vak, teacher FROM rooster WHERE klas = :klas AND dag BETWEEN :startOfWeek AND :endOfWeek";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':klas', $klas);
                $stmt->bindParam(':startOfWeek', $startOfWeek);
                $stmt->bindParam(':endOfWeek', $endOfWeek);
                $stmt->execute();
                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

                // Rooster array initialiseren
                $rooster = [];
                foreach ($dagenEngels as $dag) {
                    foreach ($tijden as $tijd) {
                        $rooster[$dag][$tijd] = '';
                    }
                }

                // Rooster vullen
                if (count($result) > 0) {
                    foreach ($result as $row) {
                        $dateTime = new DateTime($row['dag']);
                        $dayOfWeek = strtolower($dateTime->format('l')); 
                        $rooster[$dayOfWeek][$row['tijdstip']] = $row;
                    }
                }

                // Datum van de week tonen
                $startDatum = $weekDates[0]->format('d-m-Y');
                $endDatum = $weekDates[4]->format('d-m-Y');
                echo "<h2>Rooster voor $klas (Week " . ($weekOffset + 1) . ") van $startDatum tot $endDatum</h2>";

                // Rooster weergeven
                echo "<table>";
                echo "<tr><th>Dag</th>";
                foreach ($tijden as $tijd) {
                    echo "<th>" . substr($tijd, 0, 5) . "</th>";
                }
                echo "</tr>";
                foreach ($dagenEngels as $index => $dag) {
                    echo "<tr><td>" . $dagen[$index] . " (" . $weekDates[$index]->format('d-m-Y') . ")</td>";
                    foreach ($tijden as $tijd) {
                        echo "<td>";
                        if ($rooster[$dag][$tijd] == '') {
                            if ($isRoostermaker) {
                                echo "<form method='POST' action='add_lesson.php'>
                                        <input type='hidden' name='klas' value='$klas'>
                                        <input type='hidden' name='dag' value='" . $weekDates[$index]->format('Y-m-d') . "'>
                                        <input type='hidden' name='tijdstip' value='$tijd'>
                                        <input type='text' name='vak' placeholder='Vak naam' required>
                                        <input type='text' name='teacher' placeholder='Docent naam' required>
                                        <button type='submit'>+</button>
                                      </form>";
                            } else {
                                echo "";
                            }
                        } else {
                            echo $rooster[$dag][$tijd]['vak'] . " (" . $rooster[$dag][$tijd]['teacher'] . ")";
                            if ($isRoostermaker) {
                                $lessonId = $rooster[$dag][$tijd]['id'];
                                echo "<br><form method='POST' action='update_lesson.php' style='display:inline-block;'>
                                        <input type='hidden' name='id' value='$lessonId'>
                                        <input type='hidden' name='klas' value='$klas'>
                                        <input type='hidden' name='dag' value='" . $weekDates[$index]->format('Y-m-d') . "'>
                                        <input type='hidden' name='tijdstip' value='$tijd'>
                                        <input type='text' name='vak' value='" . $rooster[$dag][$tijd]['vak'] . "' required>
                                        <input type='text' name='teacher' value='" . $rooster[$dag][$tijd]['teacher'] . "' required>
                                        <button type='submit'>Update</button>
                                      </form>";
                                echo "<form method='POST' action='delete_lesson.php' style='display:inline-block;'>
                                        <input type='hidden' name='id' value='$lessonId'>
                                        <input type='hidden' name='klas' value='$klas'>
                                        <input type='hidden' name='week' value='$weekOffset'>
                                        <button type='submit'>Delete</button>
                                      </form>";
                            }
                        }
                        echo "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table>";

            } catch(PDOException $e) {
                echo "Verbinding mislukt: " . $e->getMessage();
            }
        }
        ?>
    </div>
</body>
</html>
