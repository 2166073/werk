<?php
session_start();

// Controleer of de gebruiker is ingelogd en de juiste rol heeft
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'ROOSTERMAKER') {
    header('Location: login.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $klas = $_POST['klas'];
    $week = $_POST['week'];

    // Database verbinding
    $servername = "localhost:3307";
    $usernameDB = "root";
    $passwordDB = "";
    $dbname = "databasepdo";

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $usernameDB, $passwordDB);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "DELETE FROM rooster WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $id);

        if ($stmt->execute()) {
            header("Location: indexx.php?klas=$klas&week=$week");
            exit();
        } else {
            echo "Fout bij het verwijderen van de les.";
        }
    } catch(PDOException $e) {
        echo "Verbinding mislukt: " . $e->getMessage();
    }

    $conn = null;
} else {
    echo "Ongeldige aanvraag.";
}
?>
