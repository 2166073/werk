<?php
include 'config.php';

if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $student_naam = $_POST['student_naam'];
    $gesprek_datum = $_POST['gesprek_datum'];
    $notitie = $_POST['notitie'];

    try {
        $sql = "UPDATE gesprek SET student_naam=:student_naam, gesprek_datum=:gesprek_datum, notitie=:notitie WHERE id=:id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':student_naam', $student_naam);
        $stmt->bindParam(':gesprek_datum', $gesprek_datum);
        $stmt->bindParam(':notitie', $notitie);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        header('Location: gesprekken.php');
        exit;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid request.";
}
?>
