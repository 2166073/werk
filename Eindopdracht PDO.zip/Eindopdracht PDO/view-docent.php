
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Navbar Example</title>
   <style>

    

   </style>

</head>
 
 
 
<?php
include 'Docent.php';
 
$docent = new Docent($myDb);
 
$docent = $docent->selectAlldocenten();
 
 
echo "<h1>Docenten overzicht</h1>";
echo "<table border='1'>";
echo "<tr><th>naam</th><th>klas</th><th>geboortedatum</th><th>docentennummer</th></tr>";
 
foreach ($docent as $row) {
    echo "<tr>";
    echo "<td>".$row['naam']."</td>";
    echo "<td>".$row['klas']."</td>";
    echo "<td>".$row['geboortedatum']."</td>";
    echo "<td>".$row['docentennummer']."</td>";
    
 
    echo "<td><a href='edit-docent.php?ID=".$row['ID']."'>edit</a> | <a href='delete-docent.php?ID=".$row['ID']."'>delete</a></td>";
    echo "</tr>";
}
echo "</table>";

 
 
 
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div id="center_button">
<button onclick="location.href='adddocent.php'">Voeg een docent toe</button>
</div>
</body>
</html>
 