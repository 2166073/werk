<?php
session_start();

if (!isset($_SESSION['vakken'])) {
    $_SESSION['vakken'] = [];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action']) && $_POST['action'] == 'toevoegen') {
        $vaknaam = htmlspecialchars($_POST['vaknaam']);
        if (!empty($vaknaam)) {
            $_SESSION['vakken'][] = $vaknaam;
            echo "<div class='success'>Nieuw vak succesvol toegevoegd.</div>";
        } else {
            echo "<div class='error'>Vaknaam kan niet leeg zijn.</div>";
        }
    } elseif (isset($_POST['action']) && $_POST['action'] == 'bewerken') {
        // Bewerken van bestaand vak
        $index = $_POST['index'];
        $new_vaknaam = htmlspecialchars($_POST['nieuwe_vaknaam']);
        if (!empty($new_vaknaam)) {
            $_SESSION['vakken'][$index] = $new_vaknaam;
            echo "<div class='success'>Vak succesvol bewerkt.</div>";
        } else {
            echo "<div class='error'>Vaknaam kan niet leeg zijn.</div>";
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete']) && isset($_POST['index'])) {
    $index = $_POST['index'];
    if (isset($_SESSION['vakken'][$index])) {
        unset($_SESSION['vakken'][$index]);
        $_SESSION['vakken'] = array_values($_SESSION['vakken']); 
        echo "<div class='success'>Vak succesvol verwijderd.</div>";
    } else {
        echo "<div class='error'>Geen vak gevonden om te verwijderen.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vakken Beheer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .navbar {
            width: 100%;
            background-color: #5cb85c;
            padding: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 18px;
            transition: color 0.3s;
        }
        .navbar a:hover {
            color: #e6e6e6;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
            margin-top: 20px;
        }
        h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
        }
        input[type="text"] {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box;
        }
        input[type="submit"] {
            padding: 10px;
            background-color: #5cb85c;
            border: none;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        .success {
            color: green;
            margin-top: 20px;
        }
        .error {
            color: red;
            margin-top: 20px;
        }
        .output {
            margin-top: 20px;
            padding: 10px;
            background-color: #e9ecef;
            border-radius: 4px;
        }
        .output ul {
            list-style: none;
            padding: 0;
        }
        .output ul li {
            background-color: #f9f9f9;
            padding: 10px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .output ul li:last-child {
            border-bottom: none;
        }
        .delete-form {
            display: inline-block;
        }
        .delete-button {
            background-color: #d9534f;
        }
        .delete-button:hover {
            background-color: #c9302c;
        }
        .edit-form {
            display: flex;
            align-items: center;
        }
        .edit-form input[type="text"] {
            margin-right: 10px;
        }
        .edit-button {
            background-color: #5bc0de;
        }
        .edit-button:hover {
            background-color: #46b8da;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="dashboard.php">Dashboard</a>
        <a href="overzicht_studenten.php">Overzicht Studenten</a>
        <a href="docentgegevens.php">Docent Gegevens</a>
        <a href="vakkenbeheer.php">Vakken Toevoegen</a>
        <a href="vakken_overzicht.php">Vakken Overzicht</a>

        <a href="logout.php">Uitloggen</a>
    </div>
    <div class="container">
        <h2>Voeg een nieuw schoolvak toe</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="vaknaam">Vaknaam:</label>
            <input type="text" id="vaknaam" name="vaknaam" required>
            <input type="hidden" name="action" value="toevoegen">
            <input type="submit" value="Toevoegen">
        </form>

        <h2>Huidige Vakken</h2>
        <div class="output">
            <?php if (!empty($_SESSION['vakken'])): ?>
                <ul>
                    <?php foreach ($_SESSION['vakken'] as $index => $vak): ?>
                        <li>
                            <?php echo htmlspecialchars($vak); ?>
                            <form class="edit-form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                <input type="hidden" name="index" value="<?php echo $index; ?>">
                                <input type="text" name="nieuwe_vaknaam" placeholder="Nieuwe vaknaam" required>
                                <input type="hidden" name="action" value="bewerken">
                                <input type="submit" class="edit-button" value="Bewerken">
                            </form>
                            <form class="delete-form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                <input type="hidden" name="index" value="<?php echo $index; ?>">
                                <input type="submit" class="delete-button" name="delete" value="Verwijderen">
                            </form>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>Geen vakken gevonden.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
