<?php

include 'Docent.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    try{
        $docent = new Docent($myDb);
        $docent->addDocent($_POST['naam'], $_POST['klas'], $_POST['geboortedatum'], $_POST['docentennummer']);
        header("Location: view-docent.php");
    } catch (Exception $e) {
        echo 'Error' . $e->getMessage();
        }
}


 

 
 
    ?>
 

<!DOCTYPE html>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<html lang="en">
<head> 
   
</head>
<body>
<div class="d-flex flex-column align-items-center">
    <h1>Docent toevoegen</h1>
    <form method="POST">
    <div class="mb-3">
        <input type="text" name="naam" placeholder="naam" required>
    </div>
    <div class="mb-3">
        <input type="text" name="klas" placeholder="klas" required>
    </div>
    <div class="mb-3">
        <input type="text" name="geboortedatum" placeholder="geboortedatum" required>
    </div>
    <div class="mb-3">
        <input type="text" name="docentennummer" placeholder="docentennummer" required>
    </div>
        <input type="submit" class="btn btn-primary">
    </form>
    </div>

</body>

 
   

 

</html>