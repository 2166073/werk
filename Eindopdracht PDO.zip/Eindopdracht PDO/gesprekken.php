<?php
include 'config.php';
include 'functies.php';

session_start();

$sql = "SELECT * FROM gesprek";
$stmt = $myDb->dbh->query($sql); // Gebruik de dbh van het $myDb-object
?>
<!DOCTYPE html>
<html>
<head>
    <title>Mentor Gesprek</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <header>
        <div class="container">
            <img src="logo.png" alt="IT Lyceum Logo">
            <h1>IT Lyceum - Mentor Gesprek</h1>
            <div class="dropdown">
                <?php if (is_logged_in()): ?>
                    <button><?php echo $_SESSION['username']; ?> (<?php echo $_SESSION['role']; ?>)</button>
                    <div class="dropdown-content">
                        <a href="logout.php">Logout</a>
                    </div>
                <?php else: ?>
                    <button>Account</button>
                    <div class="dropdown-content">
                        <a href="login.php">Login</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </header>        
    <?php if (is_mentor()): ?> 
        <div class="flex-container">
            <a href="add.php" class="add-button">Voeg Nieuwe Gesprek Toe</a>
        </div>
    <?php endif; ?>

    <div class="table-container">
        <div class="table-wrapper">
            <table>
                <tr>
                    <th>Student Naam</th>
                    <th>Gesprek Datum</th>
                    <th>Notitie</th>
                    <?php if (is_mentor()): ?>
                        <th>Acties</th>
                    <?php endif; ?>
                </tr>
                <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['student_naam']); ?></td>
                        <td><?php echo htmlspecialchars($row['gesprek_datum']); ?></td>
                        <td><?php echo htmlspecialchars($row['notitie']); ?></td>
                        <?php if (is_mentor()): ?>
                            <td>
                                <a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a>
                                <a href="delete.php?id=<?php echo $row['id']; ?>">Delete</a>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </div>
    <div class="table-container">
        <a href="view-docent.php">Bekijk alle docenten</a>
    </div>
    <div class="table-container">
        <a href="student_rooster.php">Voeg rooster toe</a>
    </div>
</body>
</html>

