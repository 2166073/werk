<?php
include 'config.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_naam = $_POST['student_naam'];
    $gesprek_datum = $_POST['gesprek_datum'];
    $notitie = $_POST['notitie'];

    try {
        $sql = "INSERT INTO gesprek (student_naam, gesprek_datum, notitie) VALUES (:student_naam, :gesprek_datum, :notitie)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':student_naam', $student_naam);
        $stmt->bindParam(':gesprek_datum', $gesprek_datum);
        $stmt->bindParam(':notitie', $notitie);
        $stmt->execute();
        header('Location: index.php');
        exit;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
