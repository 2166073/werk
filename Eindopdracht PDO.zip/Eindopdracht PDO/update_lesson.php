<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'ROOSTERMAKER') {
    header('Location: login.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $vak = $_POST['vak'];
    $teacher = $_POST['teacher'];
    $klas = $_POST['klas'];
    $week = $_POST['week'];

    $servername = "localhost:3306";
    $usernameDB = "root";
    $passwordDB = "";
    $dbname = "databasepdo";

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $usernameDB, $passwordDB);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "UPDATE rooster SET vak = :vak, teacher = :teacher WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':vak', $vak);
        $stmt->bindParam(':teacher', $teacher);
        $stmt->bindParam(':id', $id);

        if ($stmt->execute()) {
            header("Location: indexx.php?klas=$klas&week=$week");
            exit();
        } else {
            echo "Fout bij het bijwerken van de les.";
        }
    } catch(PDOException $e) {
        echo "Verbinding mislukt: " . $e->getMessage();
    }

    $conn = null;
} else {
    echo "Ongeldige aanvraag.";
}
?>
