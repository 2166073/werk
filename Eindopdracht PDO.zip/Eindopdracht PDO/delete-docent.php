<?php
include 'Docent.php';
 
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["ID"])) {
    $ID = $_GET["ID"];
    $docent  = new Docent($myDb);
    $docent->deletedocent($ID);
}
 
header("Location:view-docent.php");
exit();
?>