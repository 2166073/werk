<?php
$studenten = [
    ['naam' => 'Jan Jansen', 'klas' => 'OITSDO2C'],
    ['naam' => 'Piet Pietersen', 'klas' => 'OITSDO2E'],
    ['naam' => 'Klaas Klaassen', 'klas' => 'OITSDO2D'],
    ['naam' => 'Marie Maries', 'klas' => 'OITSDO2C'],
    ['naam' => 'Lisa Lisas', 'klas' => 'OITSDO2E'],
    ['naam' => 'Eva Evas', 'klas' => 'OITSDO2D'],
    ['naam' => 'John Johnson', 'klas' => 'OITSDO2C'],
    ['naam' => 'Paul Pauwels', 'klas' => 'OITSDO2E'],
    ['naam' => 'George Georges', 'klas' => 'OITSDO2D'],
    ['naam' => 'Ringo Starr', 'klas' => 'OITSDO2C'],
    ['naam' => 'Mick Mickels', 'klas' => 'OITSDO2E'],
    ['naam' => 'Keith Richards', 'klas' => 'OITSDO2D'],
    ['naam' => 'Ronnie Wood', 'klas' => 'OITSDO2C'],
    ['naam' => 'Charlie Watts', 'klas' => 'OITSDO2E'],
];

$klassen = [];
foreach ($studenten as $student) {
    $klassen[$student['klas']][] = $student['naam'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Overzicht Studenten per Klas</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .navbar {
            width: 100%;
            background-color: #5cb85c;
            padding: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 18px;
            transition: color 0.3s;
        }
        .navbar a:hover {
            color: #e6e6e6;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            width: 90%;
            max-width: 800px;
            text-align: center;
            margin-top: 20px;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        .klas {
            margin-bottom: 20px;
        }
        .klas h2 {
            color: #5cb85c;
        }
        .klas ul {
            list-style-type: none;
            padding: 0;
        }
        .klas ul li {
            background-color: #f9f9f9;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        .klas ul li:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="navbar">
    <a href="dashboard.php">Dashboard</a>
        <a href="overzicht_studenten.php">Overzicht Studenten</a>
        <a href="docentgegevens.php">Docent Gegevens</a>
        <a href="vakkenbeheer.php">Vakken Toevoegen</a>
        <a href="vakken_overzicht.php">Vakken Overzicht</a>

        <a href="logout.php">Uitloggen</a>
    </div>
    <div class="container">
        <h1>Overzicht Studenten per Klas</h1>
        <?php foreach ($klassen as $klas => $studenten): ?>
            <div class="klas">
                <h2>Klas <?php echo htmlspecialchars($klas); ?></h2>
                <ul>
                    <?php foreach ($studenten as $student): ?>
                        <li><?php echo htmlspecialchars($student); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
