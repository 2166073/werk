<?php
$vakken = [
    'Nederlands',
    'Engels',
    'Burgerschap',
    'UML',
    'Python',
    'JavaScript',
    'DataBase',
    'OOP',
    'C#',
    'OUT',
    'Rekenen',
    'BeroepsProject'
];

$docenten = [
    'Osman Oz',
    'Pengel',
    'Jeff Zwijsen',
    'Mark',
    'Bert'
];
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Overzicht van Alle Vakken</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .navbar {
            width: 100%;
            background-color: #5cb85c;
            padding: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 18px;
            transition: color 0.3s;
        }
        .navbar a:hover {
            color: #e6e6e6;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
            margin: 20px auto;
        }
        h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        .output {
            margin-top: 20px;
            padding: 10px;
            background-color: #e9ecef;
            border-radius: 4px;
        }
        .output ul {
            list-style: none;
            padding: 0;
        }
        .output ul li {
            background-color: #f9f9f9;
            padding: 10px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
        }
        .output ul li:last-child {
            border-bottom: none;
        }
        select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="dashboard.php">Dashboard</a>
        <a href="overzicht_studenten.php">Overzicht Studenten</a>
        <a href="docentgegevens.php">Docent Gegevens</a>
        <a href="vakkenbeheer.php">Vakken Toevoegen</a>
        <a href="vakken_overzicht.php">Vakken Overzicht</a>
        <a href="logout.php">Uitloggen</a>
    </div>
    <div class="container">
        <h2>Overzicht van Alle Vakken</h2>
        <div class="output">
            <?php if (!empty($vakken)): ?>
                <ul>
                    <?php foreach ($vakken as $index => $vak): ?>
                        <li>
                            <?php echo htmlspecialchars($vak); ?>
                            <select>
                                <option value="">Kies docent</option>
                                <?php foreach ($docenten as $docent): ?>
                                    <option value="<?php echo htmlspecialchars($docent); ?>"><?php echo htmlspecialchars($docent); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>Geen vakken gevonden.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
