<?php
include 'config.php';
include 'functies.php';

check_login();

$id = $_GET['id'];
$sql = "SELECT * FROM gesprek WHERE id=:id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':id', $id);
$stmt->execute();

$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    echo "No record found!";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Gesprek</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <header>
        <div class="container">
            <img src="logo.png" alt="IT Lyceum Logo">
            <h1>IT Lyceum - Mentor Gesprek</h1>
            <div class="dropdown">
                <?php if (is_logged_in()): ?>
                    <button><?php echo $_SESSION['username']; ?> (<?php echo $_SESSION['role']; ?>)</button>
                    <div class="dropdown-content">
                        <a href="logout.php">Logout</a>
                    </div>
                <?php else: ?>
                    <button>Account</button>
                    <div class="dropdown-content">
                        <a href="login.php">Login</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <div class="container">
        <h1>Edit Gesprek</h1>
        <form action="update.php" method="post">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <label for="student_naam">Student Naam:</label>
            <input type="text" id="student_naam" name="student_naam" value="<?php echo htmlspecialchars($row['student_naam']); ?>" required>
            <label for="gesprek_datum">Gesprek Datum:</label>
            <input type="date" id="gesprek_datum" name="gesprek_datum" value="<?php echo htmlspecialchars($row['gesprek_datum']); ?>" required>
            <label for="notitie">Notitie:</label>
            <textarea id="notitie" name="notitie" required><?php echo htmlspecialchars($row['notitie']); ?></textarea>
            <button type="submit">Edit</button>
        </form>
        <a href="gesprekken.php">Terug naar Gesprekken</a>
    </div>
</body>
</html>
