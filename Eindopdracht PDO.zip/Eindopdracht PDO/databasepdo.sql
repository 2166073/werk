-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Gegenereerd op: 27 jun 2024 om 15:00
-- Serverversie: 10.4.28-MariaDB
-- PHP-versie: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `databasepdo`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `docent`
--

CREATE TABLE `docent` (
  `ID` int(11) NOT NULL,
  `naam` varchar(255) NOT NULL,
  `klas` varchar(255) NOT NULL,
  `geboortedatum` varchar(255) NOT NULL,
  `docentennummer` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `docent`
--

INSERT INTO `docent` (`ID`, `naam`, `klas`, `geboortedatum`, `docentennummer`) VALUES
(1, 'Johan van Dijk', '2B', '1975-05-14', 12345),
(2, 'Lisa de Boer', '3C', '1980-08-23', 23456);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `gesprek`
--

CREATE TABLE `gesprek` (
  `id` int(100) NOT NULL,
  `student_naam` varchar(100) DEFAULT NULL,
  `gesprek_datum` date DEFAULT NULL,
  `notitie` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `gesprek`
--

INSERT INTO `gesprek` (`id`, `student_naam`, `gesprek_datum`, `notitie`) VALUES
(1, 'Jaber', '2024-07-26', 'Rapport en Lamm'),
(14, 'Zakaria', '2000-11-11', 'Bespreking');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `klas`
--

CREATE TABLE `klas` (
  `ID` int(11) NOT NULL,
  `naam` varchar(255) NOT NULL,
  `aantalstudenten` int(11) NOT NULL,
  `mentor` varchar(255) NOT NULL,
  `opleiding` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `klas`
--

INSERT INTO `klas` (`ID`, `naam`, `aantalstudenten`, `mentor`, `opleiding`) VALUES
(1, '2B', 25, 'Johan van Dijk', 'Informatica'),
(2, '3C', 30, 'Lisa de Boer', 'Wiskunde');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `rooster`
--

CREATE TABLE `rooster` (
  `id` int(55) NOT NULL,
  `klas` varchar(55) NOT NULL,
  `dag` varchar(55) NOT NULL,
  `tijdstip` varchar(55) NOT NULL,
  `vak` varchar(55) NOT NULL,
  `teacher` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `rooster`
--

INSERT INTO `rooster` (`id`, `klas`, `dag`, `tijdstip`, `vak`, `teacher`) VALUES
(1, 'OTITOSD2C', '2024-06-24', '08:30:00', 'Database', 'Osman'),
(2, 'OTITOSD2E', '2024-06-24', '08:30:00', 'UML', 'Jeff'),
(3, 'OTITOSD2B', '2024-06-24', '08:30:00', 'OOP1', 'Bert'),
(4, 'OTITOSD2C', '2024-06-24', '09:30:00', 'OOP1', 'Bert'),
(5, 'OTITOSD2C', '2024-06-24', '10:30:00', 'Python', 'Mark');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `student`
--

CREATE TABLE `student` (
  `ID` int(11) NOT NULL,
  `naam` varchar(255) NOT NULL,
  `klas` varchar(255) NOT NULL,
  `mentor` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `student`
--

INSERT INTO `student` (`ID`, `naam`, `klas`, `mentor`) VALUES
(1, 'Piet Jansen', '2B', 'Johan van Dijk'),
(2, 'Kees de Groot', '3C', 'Lisa de Boer');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'mentor', '482c811da5d5b4bc6d497ffa98491e38', 'MENTOR'),
(3, 'Osman', '78b6c1cd9f90d2560525966c76d8d398', 'DOCENT'),
(6, 'docent', '365d38c60c4e98ca5ca6dbc02d396e53', 'DOCENT'),
(7, 'student', 'db6ae64dfa9e78039db6df5b8edbc38c', 'STUDENT'),
(8, 'Manager', 'e64b78fc3bc91bcbc7dc232ba8ec59e0', 'MANAGER'),
(10, 'Roostermaker', '365d38c60c4e98ca5ca6dbc02d396e53', 'ROOSTERMAKER'),
(11, 'zakaria', '4c148b6b5797433dab2b0f4efb530a91', 'STUDENT');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `docent`
--
ALTER TABLE `docent`
  ADD PRIMARY KEY (`ID`);

--
-- Indexen voor tabel `gesprek`
--
ALTER TABLE `gesprek`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `klas`
--
ALTER TABLE `klas`
  ADD PRIMARY KEY (`ID`);

--
-- Indexen voor tabel `rooster`
--
ALTER TABLE `rooster`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `docent`
--
ALTER TABLE `docent`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `gesprek`
--
ALTER TABLE `gesprek`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT voor een tabel `klas`
--
ALTER TABLE `klas`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `rooster`
--
ALTER TABLE `rooster`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT voor een tabel `student`
--
ALTER TABLE `student`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
