<?php
function check_login() {
    session_start();
    if (!isset($_SESSION['username']) || $_SESSION['role'] != 'MENTOR') {
        header('Location: login.php');
        exit();
    }
}

function is_mentor() {
    return isset($_SESSION['role']) && $_SESSION['role'] == 'MENTOR';
}

function is_logged_in() {
    return isset($_SESSION['username']);
}
?>
