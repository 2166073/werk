<?php
include 'config.php';
include 'functies.php';

check_login();

$id = $_GET['id'];

try {
    $sql = "DELETE FROM gesprek WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header('Location: gesprekken.php');
    exit;
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
