<?php
include 'config.php';
   

 
 
 class Docent{
    private $dbh;

    public function __construct($dbh)
    {
        $this->dbh = $dbh;

    }
    public function adddocent($naam, $klas, $geboortedatum, $docentennummer)
    {
        return $this->dbh->execute("INSERT INTO docent (naam, klas, geboortedatum, docentennummer)
        VALUES (?,?,?,?)",
        [$naam, $klas, $geboortedatum, $docentennummer]);
    }
    public function selectAlldocenten(){
        return $this->dbh->execute("SELECT * FROM docent");
    }
    public function updatedocent( $naam, $klas, $geboortedatum, $docentennummer, $ID) {
        $sql = "UPDATE docent SET naam = ?,  klas = ?,  geboortedatum = ?, docentennummer= ? WHERE ID = ?";
        return $this->dbh->execute($sql, array($naam, $klas, $geboortedatum, $docentennummer, $ID));
    }
    

    public function getdocentById($ID) {
        $sql = "SELECT * FROM docent WHERE ID = ?";
        $stmt = $this->dbh->execute($sql, array($ID));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function deletedocent($ID) {
        $sql = "DELETE FROM docent WHERE ID = ?";
        return $this->dbh->execute($sql, array($ID));
    }


}


 
?>
 

 
